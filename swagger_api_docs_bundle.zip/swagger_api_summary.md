# NowFit Swagger API Summary

| Method | Endpoint | Summary | Tag | File |
|--------|----------|---------|-----|------|
| GET | /api/members | 전체 회원 조회 | Members | memberRoutes.js |
| POST | /api/members | 회원 등록 | Members | memberRoutes.js |
| PATCH | /api/members/{id}/status | 회원 상태 변경 | Members | memberRoutes.js |
| PATCH | /api/members/{id}/points | 회원 포인트 변경 | Members | memberRoutes.js |
| GET | /api/members/search | 회원 검색 | Members | memberRoutes.js |
| POST | /api/attendance | 출석 등록 | Attendance | attendanceRoutes.js |
| GET | /api/attendance/member/{id} | 회원별 출석 조회 | Attendance | attendanceRoutes.js |
| POST | /api/diet | 식단 등록 | Diet | dietRoutes.js |
| GET | /api/diet | 전체 식단 조회 (필터) | Diet | dietRoutes.js |
| GET | /api/diet/member/{id} | 회원별 식단 조회 | Diet | dietRoutes.js |
| POST | /api/consultations | 상담 등록 | Consultation | consultationRoutes.js |
| GET | /api/consultations/member/{id} | 회원별 상담 조회 | Consultation | consultationRoutes.js |
| POST | /api/exercise | 운동 기록 등록 | Exercise | exerciseRoutes.js |
| GET | /api/exercise/{id} | PT 일정별 운동 기록 조회 | Exercise | exerciseRoutes.js |
| POST | /api/exercise-goals | 운동 목표 등록 | ExerciseGoals | exerciseGoalRoutes.js |
| GET | /api/exercise-goals/member/{id} | 회원별 운동 목표 조회 | ExerciseGoals | exerciseGoalRoutes.js |
| POST | /api/media | 미디어 등록 | Media | mediaRoutes.js |
| GET | /api/media | 전체 미디어 조회 | Media | mediaRoutes.js |
| GET | /api/media/member/{id} | 회원별 미디어 조회 | Media | mediaRoutes.js |
| POST | /api/bodymetrics | 신체 측정 등록 | BodyMetrics | bodyMetricsRoutes.js |
| GET | /api/bodymetrics/member/{id} | 회원별 신체 측정 기록 | BodyMetrics | bodyMetricsRoutes.js |
| GET | /api/bodymetrics/member/{id}/latest | 회원별 최근 측정 1건 | BodyMetrics | bodyMetricsRoutes.js |
| GET | /api/calendar | 전체 캘린더 조회 | Calendar | calendarRoutes.js |
| POST | /api/membership-alerts | 회원권 알림 전송 | System | membershipAlertRoutes.js |
| POST | /api/ptschedules | PT 일정 등록 | PTSchedules | ptScheduleRoutes.js |
| GET | /api/ptschedules | 전체 수업 조회 (트레이너 필터 포함) | PTSchedules | ptScheduleRoutes.js |
| DELETE | /api/ptschedules/{id} | 수업 삭제 및 복구 | PTSchedules | ptScheduleRoutes.js |
| PATCH | /api/pt/{id}/complete | 수업 완료 처리 | PT | ptRoutes.js |
| DELETE | /api/pt/{id} | 수업 삭제 및 잔여횟수 복구 | PT | ptRoutes.js |
| GET | /api/pt/calendar | 달력용 스케줄 조회 | PT | ptRoutes.js |
| GET | /api/pt/{id}/stats | 수업 통계 조회 | PT | ptRoutes.js |
| GET | /api/pt/{id}/dates | 수업 완료 날짜 목록 | PT | ptRoutes.js |
| GET | /api/ptstats/{id}/sessions | 회원별 수업 상태 통계 | PTStats | ptStatsRoutes.js |
| GET | /api/ptstats/{id}/progress | 운동 진척도 그래프 | PTStats | ptStatsRoutes.js |
| POST | /api/ptpasses | PT권 등록 | PTPass | ptPassRoutes.js |
| GET | /api/ptpasses | 전체 PT권 조회 (필터) | PTPass | ptPassRoutes.js |
| GET | /api/ptpasses/member/{id} | 회원별 PT권 조회 | PTPass | ptPassRoutes.js |
| GET | /api/ptdetail/{id} | PT 상세 정보 조회 | PT | ptDetailRoutes.js |
| PATCH | /api/pt-autocancel/autocancel | 출석 없는 PT 자동 취소 | PT | ptAutoCancelRoutes.js |
| PATCH | /api/points/{id} | 회원 포인트 수정 | Points | pointRoutes.js |
| GET | /api/summary-stats/member/{id} | 회원별 요약 통계 조회 | SummaryStats | summaryStatsRoutes.js |
| POST | /api/summary-stats | 요약 통계 수동 갱신 | SummaryStats | summaryStatsRoutes.js |
| GET | /api/users | 사용자 목록 조회 | Users | userRoutes.js |
| POST | /api/users | 사용자 등록 | Users | userRoutes.js |
| PATCH | /api/users/{id}/status | 사용자 상태 변경 | Users | userRoutes.js |
| GET | /api/search | 회원 검색 (통합) | Search | searchRoutes.js |
| PATCH | /api/status/{id} | 회원 상태 수정 | Members | statusRoutes.js |
| POST | /api/referrals/register | 회원 추천 등록 | Referral | referralRoutes.js |
| GET | /api/notifications/expiring | 만료 임박 회원 조회 | Notifications | notificationRoutes.js |
| GET | /api/member-stats/status | 회원 상태 통계 | Members | memberStatsRoutes.js |
